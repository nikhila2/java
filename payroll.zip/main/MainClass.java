package com.cg.payroll.main;
import com.cg.payroll.bean.Associate;
import com.cg.payroll.bean.BankDetails;
import com.cg.payroll.bean.Salary;
public class MainClass {
	public static void main(String[] args) {
		String name="Shishir";
		Associate a1=searchInvestmentSalary(name);
		if(a1!=null){
			System.out.println(a1.getLastName());
			System.out.println("record found");
		}
			else{
				System.out.println("record Not found");
}
	}

	private static Associate searchInvestmentSalary(String n) {
		Associate[] associate=new Associate[3];
		associate[0]=new Associate(2345, 20000, "Shishir", "Reddy", "training", "Software", "asdfg23l", "shishir06@gmail.com", new Salary(16000, 300, 200, 30, 100, 500, 2000, 1000, 100, 2000, 3000),new BankDetails(1234, "hdfc", "hdfc2002"));
		associate[1]=new Associate(2345, 20000, "Nikhila", "Reddy", "trainer", "Software", "asdfg23l", "shishir06@gmail.com", new Salary(1000, 300, 200, 30, 100, 500, 2000, 1000, 100, 2000, 3000),new BankDetails(1234, "hdfc", "hdfc2002"));
		for (Associate associate2 : associate) {
			if(associate2!=null&&associate2.getFirstName()==n&&associate2.getSalary().getBasicSalary()>1500)
				return associate2;
		}
		return null;
	}
}